// index.js — Stocked Worker entry point (modular).
//
// Preserves the shipped app's contract exactly:
//   • X-Stocked-Key shared-secret gate
//   • POST "/" with a payload → the 7 legacy AI routes, response is the Anthropic
//     envelope with content[0].text (+ schemaVersion/route/workerVersion)
//   • /household/* and /crowd/* request/response shapes
// Adds: Durable Object household sync, native rate limiting, ctx.waitUntil,
// request IDs + structured logs, upstream timeout/breaker/fallback + output
// validation, new pathname AI endpoints, /recipes/discover, /daily-brief, and
// short-lived Apple session auth. See MANUAL_STEPS.md for bindings/secrets.

import { CORS_HEADERS, json, withCors, makeRequestId, logEvent, background } from "./src/util.js";
import { validateInput } from "./src/validation.js";
import { callAnthropicResilient, runValidatedRoute, extractText } from "./src/ai.js";
import { buildLegacyPrompt, buildRoutePrompt, PATH_ROUTES, ROUTE_SCHEMA } from "./src/routes.js";
import { handleHousehold } from "./src/household.js";
import { handleCrowd } from "./src/crowd.js";
import { handleDiscover } from "./src/discover.js";
import { handleDailyBrief, handleBriefQueue, handleScheduledBriefs } from "./src/dailybrief.js";
import { handleConfiguration } from "./src/config.js";
import { handleBarcodeResolve } from "./src/barcodes.js";
import { handleDiagnostics } from "./src/diagnostics.js";
import { handlePricesCompare } from "./src/prices.js";
import { sharedKeyOK, verifyAppleIdentityToken, issueSession, verifySession, verifyAttestation } from "./src/auth.js";
import { isLimited, limiterFor } from "./src/ratelimit.js";
import { HouseholdDO } from "./src/household-do.js";

export { HouseholdDO }; // Durable Object must be exported from the entry module.

const WORKER_VERSION = "2026-07-15.1";
const DEFAULT_MODEL = "claude-sonnet-5";
const FALLBACK_MODEL = "claude-haiku-4-5-20251001";
const MAX_BODY_BYTES = 2 * 1024 * 1024;

// Routes that require App Attest when enabled (expensive AI paths).
const EXPENSIVE_ROUTES = new Set(["receiptImage", "recipeGeneration", "recipeEnrich", "recipeBuildAround", "mealPlanOptimize"]);

function aiResultURL(key) { return "https://ai-cache.internal/" + encodeURIComponent(key); }

export default {
  async fetch(request, env, ctx) {
    const requestId = makeRequestId();
    const started = Date.now();
    const url = new URL(request.url);
    let route = "unknown", status = 200;
    try {
      if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS_HEADERS });

      if (url.pathname === "/health") {
        return json({
          ok: true, version: WORKER_VERSION,
          hasAnthropicKey: !!env.ANTHROPIC_API_KEY,
          hasSharedKey: !!env.STOCKED_SHARED_KEY,
          hasSessionKey: !!env.SESSION_SIGNING_KEY,
          hasHouseholdDO: !!env.HOUSEHOLD_DO,
        }, 200);
      }

      // Coarse outer gate (shared secret still ships as a first filter).
      if (!sharedKeyOK(request, env)) { status = 401; return json({ error: "Unauthorized", requestId }, 401); }

      // ── Remote configuration (GET; kill switches / flags / maintenance) ──
      if (request.method === "GET" && url.pathname === "/configuration") {
        route = "configuration";
        return await handleConfiguration(request, env, ctx);
      }

      // ── Session issuance (Apple / guest) ──
      if (request.method === "POST" && url.pathname === "/session/apple") {
        route = "sessionApple";
        const b = await request.json().catch(() => ({}));
        const v = await verifyAppleIdentityToken(b.identityToken || "", env.APPLE_BUNDLE_ID);
        if (!v.ok) { status = 401; return json({ error: "Apple token invalid", reason: v.reason, requestId }, 401); }
        const token = await issueSession(env, { sub: v.sub, guest: false, ttlSeconds: 3600 });
        return json({ session: token, expiresIn: 3600 });
      }
      if (request.method === "POST" && url.pathname === "/session/guest") {
        route = "sessionGuest";
        const token = await issueSession(env, { sub: "guest", guest: true, ttlSeconds: 3600 });
        return json({ session: token, expiresIn: 3600, guest: true });
      }

      // ── Household (Durable Object) ──
      if (url.pathname.startsWith("/household")) {
        route = "household";
        if (!env.HOUSEHOLD_DO) { status = 500; return json({ error: "Server misconfigured (no HOUSEHOLD_DO)" }, 500); }
        // Only WRITES are rate-limited (matching the original worker). The app polls
        // pull/presence every ~6s — throttling reads stalls sync and surfaces as
        // "Too many requests". The DO serializes writes and has its own protection.
        if (url.pathname === "/household/push") {
          if (await isLimited(limiterFor(env, "household"), request.headers.get("CF-Connecting-IP") || "unknown", "hh")) {
            status = 429; return json({ error: "Too many changes; slow down", code: "rateLimited" }, 429);
          }
        }
        return await handleHousehold(url.pathname, request, env);
      }

      // ── Crowd DB ──
      if (url.pathname.startsWith("/crowd")) {
        route = "crowd";
        if (!env.CROWD) { status = 500; return json({ error: "Server misconfigured (no CROWD KV)" }, 500); }
        if (await isLimited(limiterFor(env, "crowd"), request.headers.get("CF-Connecting-IP") || "unknown", "crowd")) {
          status = 429; return json({ error: "Rate limit exceeded", code: "rateLimited" }, 429);
        }
        return await handleCrowd(url, request, env, ctx);
      }

      // Everything below is POST-only.
      if (request.method !== "POST") { status = 405; return json({ error: "Method not allowed" }, 405); }

      // Per-IP rate limit (class chosen per route below; this is the coarse default).
      const ip = request.headers.get("CF-Connecting-IP") || "unknown";

      // ── Non-AI new endpoints ──
      if (url.pathname === "/recipes/discover") {
        route = "discover";
        if (await isLimited(limiterFor(env, "default"), ip, "disc")) { status = 429; return json({ error: "Rate limit exceeded" }, 429); }
        return await handleDiscover(request, env, ctx);
      }
      if (url.pathname === "/daily-brief/generate") {
        route = "dailyBrief";
        if (await isLimited(limiterFor(env, "default"), ip, "brief")) { status = 429; return json({ error: "Rate limit exceeded" }, 429); }
        return await handleDailyBrief(request, env, ctx);
      }
      if (url.pathname === "/barcodes/resolve") {
        route = "barcodeResolve";
        if (await isLimited(limiterFor(env, "default"), ip, "barc")) { status = 429; return json({ error: "Rate limit exceeded" }, 429); }
        return await handleBarcodeResolve(request, env, ctx);
      }
      if (url.pathname === "/support/diagnostics") {
        route = "diagnostics";
        return await handleDiagnostics(request, env, ctx);
      }
      if (url.pathname === "/prices/compare") {
        route = "priceCompare";
        if (await isLimited(limiterFor(env, "default"), ip, "price")) { status = 429; return json({ error: "Rate limit exceeded" }, 429); }
        return await handlePricesCompare(request, env, ctx);
      }

      // ── Body read for AI routes ──
      const lenHeader = parseInt(request.headers.get("Content-Length") || "0", 10);
      if (lenHeader && lenHeader > MAX_BODY_BYTES) { status = 413; return json({ error: "Payload too large" }, 413); }
      let payload;
      try {
        const raw = await request.text();
        if (raw.length > MAX_BODY_BYTES) { status = 413; return json({ error: "Payload too large" }, 413); }
        payload = JSON.parse(raw);
      } catch { status = 400; return json({ error: "Invalid JSON" }, 400); }

      // Resolve which prompt to build: new pathname endpoint, or legacy payload sniff.
      const pathRoute = PATH_ROUTES[url.pathname];
      const prompt = pathRoute ? buildRoutePrompt(pathRoute, payload) : buildLegacyPrompt(payload);
      if (!prompt) { status = 422; return json({ error: "Unrecognized request", requestId }, 422); }
      route = prompt.route;

      // Input validation with stable error codes (#7). Legacy routes are validated
      // against their known field schema; new routes rely on output validation.
      const vin = validateInput(prompt.route, payload);
      if (!vin.ok) { status = 422; return json({ error: "Validation failed", code: "invalidInput", errors: vin.errors, requestId }, 422); }

      // Route class → rate limiter.
      const kind = (prompt.route === "receiptImage" || prompt.route === "receiptText") ? "receipt" : "ai";
      if (await isLimited(limiterFor(env, kind), ip, kind)) { status = 429; return json({ error: "Rate limit exceeded", code: "rateLimited" }, 429); }

      // App Attest gate for expensive routes (opt-in; no-op until enabled).
      if (EXPENSIVE_ROUTES.has(prompt.route)) {
        const att = await verifyAttestation(env, {
          keyId: request.headers.get("X-Stocked-Attest-Key") || "",
          assertion: request.headers.get("X-Stocked-Attest") || "",
          clientDataHash: request.headers.get("X-Stocked-Attest-Hash") || "",
          deviceKeyJwk: payload.__attestKey || null,
        });
        if (!att.ok) { status = 403; return json({ error: "Attestation required", code: "attestationFailed", reason: att.reason, requestId }, 403); }
      }
      delete payload.__attestKey;

      if (!env.ANTHROPIC_API_KEY) { status = 500; return json({ error: "Worker is missing ANTHROPIC_API_KEY" }, 500); }

      // Edge cache for deterministic passthrough routes.
      const cacheKey = prompt.cacheKey ? aiResultURL(`${prompt.cacheKey}:${WORKER_VERSION}`) : null;
      if (cacheKey) { const hit = await caches.default.match(cacheKey); if (hit) return withCors(hit); }

      const models = [env.ANTHROPIC_MODEL || DEFAULT_MODEL, FALLBACK_MODEL];

      // Validated routes: parse+validate+repair, then hand the app clean JSON in content[0].text.
      if (prompt.validated) {
        const r = await runValidatedRoute({
          env, route: prompt.route, schemaVersion: prompt.schemaVersion, models,
          system: prompt.system, user: prompt.user, maxTokens: prompt.maxTokens, requestId,
        });
        if (!r.ok) { status = 502; return json({ error: "Assistant output invalid", code: r.code || "upstreamError", errors: r.errors, requestId }, 502); }
        const envelope = {
          content: [{ type: "text", text: JSON.stringify(r.value) }],
          schemaVersion: prompt.schemaVersion, route: prompt.route, workerVersion: WORKER_VERSION,
          model: r.model, repaired: !!r.repaired, requestId,
        };
        logEvent({ requestId, route: prompt.route, status: 200, ms: Date.now() - started, model: r.model, repaired: !!r.repaired });
        return json(envelope, 200);
      }

      // Passthrough routes: return the Anthropic envelope unchanged (+ our fields).
      const res = await callAnthropicResilient({ env, models, system: prompt.system, user: prompt.user, maxTokens: prompt.maxTokens, requestId });
      if (!res.ok) { status = 502; return json({ error: "Assistant upstream error", upstreamStatus: res.status, requestId }, 502); }
      let envelope;
      try { envelope = JSON.parse(res.text); } catch { status = 502; return json({ error: "Assistant returned invalid JSON envelope", requestId }, 502); }
      envelope.schemaVersion = prompt.schemaVersion;
      envelope.route = prompt.route;
      envelope.workerVersion = WORKER_VERSION;
      envelope.requestId = requestId;
      const response = json(envelope, 200, prompt.cacheTTL ? { "Cache-Control": `max-age=${prompt.cacheTTL}` } : {});
      if (cacheKey && prompt.cacheTTL) background(ctx, caches.default.put(cacheKey, response.clone()));
      logEvent({ requestId, route: prompt.route, status: 200, ms: Date.now() - started, model: res.model });
      return response;
    } catch (e) {
      logEvent({ requestId, route, event: "workerCrash", error: String((e && e.message) || e) });
      return json({ error: "Worker threw: " + String((e && e.message) || e), code: "workerCrash", requestId }, 500);
    } finally {
      if (route !== "unknown") logEvent({ requestId, route, status, ms: Date.now() - started, phase: "end" });
    }
  },

  // Cron Triggers → enqueue daily briefs.
  async scheduled(event, env, ctx) {
    ctx.waitUntil(handleScheduledBriefs(event, env, ctx));
  },

  // Queues consumer → generate/deliver briefs with retries + dead-letter.
  async queue(batch, env, ctx) {
    await handleBriefQueue(batch, env, ctx);
  },
};
