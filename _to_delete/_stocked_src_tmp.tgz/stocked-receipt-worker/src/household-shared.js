// household-shared.js — pure helpers shared by the Durable Object. These are
// lifted verbatim (behavior-preserving) from the original index.js so the merge,
// tombstone, revision, and sanitize semantics are byte-for-byte identical.

export const HH_MAX_ITEMS = 2000;
export const HH_MAX_ACTIVITY = 200;
export const HH_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

export const ROLE_DEFAULTS = {
  owner:   { add: true,  edit: true,  remove: true },
  manager: { add: true,  edit: true,  remove: true },
  adult:   { add: true,  edit: true,  remove: true },
  teen:    { add: true,  edit: true,  remove: false },
  kid:     { add: false, edit: false, remove: false },
  member:  { add: true,  edit: true,  remove: true },
};

export function normalizeCode(raw) {
  if (typeof raw !== "string") return "";
  return raw.toUpperCase().split("").filter((c) => HH_CODE_ALPHABET.includes(c)).join("");
}

export function sanitizeName(raw) {
  if (typeof raw !== "string" || !raw.trim()) return "Member";
  return raw.trim().slice(0, 40);
}

export function sanitizeId(raw) {
  if (typeof raw !== "string") return "";
  return raw.trim().slice(0, 64);
}

export function appendActivity(list, newEvent) {
  let arr = Array.isArray(list) ? list.slice() : [];
  if (newEvent) arr.push(newEvent);
  const seen = new Set();
  arr = arr.filter((event) => {
    const key = [event.kind, event.itemName, event.oldName, event.actorName, event.date].join("|");
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
  arr.sort((a, b) => (b.date || 0) - (a.date || 0));
  return arr.slice(0, HH_MAX_ACTIVITY);
}

export function mergeLWW(existing, incoming, deleted) {
  const byId = new Map();
  let anon = 0;
  const put = (item) => {
    if (!item) return;
    const key = item.id != null ? String(item.id) : "anon_" + anon++;
    if (deleted && deleted.has(key)) return;
    const prev = byId.get(key);
    if (!prev) { byId.set(key, item); return; }
    const a = Number(item.updatedAt || 0), b = Number(prev.updatedAt || 0);
    const aw = String(item.lastWriterID || ""), bw = String(prev.lastWriterID || "");
    if (a > b || (a === b && aw > bw)) byId.set(key, item);
  };
  for (const it of Array.isArray(existing) ? existing : []) put(it);
  for (const it of Array.isArray(incoming) ? incoming : []) put(it);
  return Array.from(byId.values()).sort((a, b) => String(a.id || "").localeCompare(String(b.id || "")));
}

export function dedupeCap(arr, cap) {
  const seen = new Set();
  const out = [];
  for (const v of Array.isArray(arr) ? arr : []) {
    const s = String(v);
    if (!seen.has(s)) { seen.add(s); out.push(s); }
  }
  return out.slice(-cap);
}

export function semanticHousehold(household) {
  const copy = JSON.parse(JSON.stringify(household || {}));
  delete copy.updatedAt;
  delete copy.revision;
  for (const key of ["inventory", "grocery", "userRecipes", "genRecipes", "plannedMeals", "members"]) {
    if (Array.isArray(copy[key])) copy[key].sort((a, b) => String((a && (a.id || a.memberId)) || "").localeCompare(String((b && (b.id || b.memberId)) || "")));
  }
  for (const key of ["invDeleted", "groDeleted", "userRecipeDeleted", "genRecipeDeleted", "mealDeleted"]) {
    if (Array.isArray(copy[key])) copy[key] = Array.from(new Set(copy[key].map(String))).sort();
  }
  if (Array.isArray(copy.activity)) copy.activity = appendActivity(copy.activity, null);
  return copy;
}
