// household.js — Worker-side forwarder to the HouseholdDO.
//
// Translates the app's /household/<action> POSTs into DO calls. One DO per code
// (idFromName(code)). Preserves every request/response shape. Code allocation and
// regenerate (which moves a doc between codes) are orchestrated here because they
// span two DO instances.

import { makeHouseholdCode, json } from "./util.js";
import { normalizeCode } from "./household-shared.js";

function stub(env, code) {
  const id = env.HOUSEHOLD_DO.idFromName(code);
  return env.HOUSEHOLD_DO.get(id);
}

async function callDO(env, code, action, body) {
  const res = await stub(env, code).fetch("https://do.internal/", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    // `code` here is already normalized (matches the DO id + KV "hh:" key), so the DO can
    // seed itself from the legacy KV snapshot using the correct key.
    body: JSON.stringify({ action, code, body }),
  });
  const text = await res.text();
  let parsed; try { parsed = JSON.parse(text); } catch { parsed = { error: "DO returned non-JSON" }; }
  return { status: res.status, body: parsed };
}

export async function handleHousehold(pathname, request, env) {
  let body;
  try { body = JSON.parse(await request.text()); } catch { return json({ error: "Invalid JSON" }, 400); }
  const action = pathname.replace(/^\/household\/?/, "");

  // create: allocate an unused code, then init that DO.
  if (action === "create") {
    for (let attempt = 0; attempt < 8; attempt++) {
      const code = makeHouseholdCode();
      const r = await callDO(env, code, "create", { ...body, code });
      if (r.status === 409) continue; // collision, try another code
      return json(r.body, r.status);
    }
    return json({ error: "Could not allocate a code, try again" }, 503);
  }

  // regenerate: read old doc, init a fresh code's DO with it, destroy the old.
  if (action === "regenerate") {
    const oldCode = normalizeCode(body.code);
    const pulled = await callDO(env, oldCode, "pull", { code: oldCode });
    if (pulled.status === 404 || !pulled.body.household) return json({ error: "share not found", code: "notFound" }, 404);
    for (let attempt = 0; attempt < 8; attempt++) {
      const newCode = makeHouseholdCode();
      if (newCode === oldCode) continue;
      const exists = await callDO(env, newCode, "exists", {});
      if (exists.body && exists.body.exists) continue;
      const imported = await callDO(env, newCode, "import", { code: newCode, household: pulled.body.household });
      if (imported.status >= 400) continue;
      await callDO(env, oldCode, "destroy", {});
      return json(imported.body, imported.status);
    }
    return json({ error: "Could not allocate a new code, try again" }, 503);
  }

  // All other actions forward straight to the code's DO.
  const known = ["join", "pull", "presence", "push", "setrole", "setname", "leave"];
  if (known.includes(action)) {
    const code = normalizeCode(body.code);
    const r = await callDO(env, code, action, body);
    return json(r.body, r.status);
  }

  return json({ error: "Unknown household action" }, 404);
}
