// config.js — GET /configuration (new function).
//
// Remotely managed app config so you can change behavior WITHOUT an App Store
// update: feature flags, min supported version, disabled recipe sources, request
// limits, a maintenance message, AI model selection, rollout %, and emergency
// kill switches. Stored in KV under "config:current" so you edit it live:
//     wrangler kv key put --binding=RATE_KV config:current '{"...":"..."}'
// No redeploy needed. Served over the authenticated (X-Stocked-Key) + TLS channel
// and cached briefly. An HMAC signature is attached for optional tamper-evidence.

import { json, sha256Hex } from "./util.js";

const KV_KEY = "config:current";
const CACHE_URL = "https://config.internal/current";
const CACHE_TTL_S = 60;

// Safe defaults if nothing is in KV yet — nothing disabled, no maintenance.
const DEFAULT_CONFIG = Object.freeze({
  schemaVersion: 1,
  minSupportedVersion: "0.0.0",
  maintenance: { active: false, message: "" },
  featureFlags: {},              // e.g. { "cookNowV2": true }
  disabledRecipeSources: [],     // e.g. ["Spoonacular"]
  killSwitches: {},              // e.g. { "aiRecipeGeneration": false }
  aiModel: null,                 // null → worker uses its default
  requestLimits: {},             // advisory limits the app can honor
  rollout: {},                   // e.g. { "newDashboard": 25 } (percent)
});

async function loadConfig(env) {
  try {
    const raw = env.RATE_KV ? await env.RATE_KV.get(KV_KEY) : null;
    if (!raw) return DEFAULT_CONFIG;
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_CONFIG, ...parsed };
  } catch {
    return DEFAULT_CONFIG;
  }
}

/** GET /configuration → signed, cached config. */
export async function handleConfiguration(request, env, _ctx) {
  // Serve from edge cache when warm (config changes are infrequent).
  try {
    const hit = await caches.default.match(CACHE_URL);
    if (hit) return hit;
  } catch {}

  const config = await loadConfig(env);
  const body = JSON.stringify(config);
  // Best-effort integrity tag. TLS already protects transport; this lets the app
  // detect a stale/edited cached copy if it ever wants to (see MANUAL_STEPS §config).
  const sig = env.SESSION_SIGNING_KEY ? await sha256Hex(body + env.SESSION_SIGNING_KEY) : null;

  const headers = { "Cache-Control": `max-age=${CACHE_TTL_S}` };
  if (sig) headers["ETag"] = `"${sig.slice(0, 16)}"`;
  const response = json({ config, sig, servedAt: Date.now() }, 200, headers);
  try { await caches.default.put(CACHE_URL, response.clone()); } catch {}
  return response;
}
