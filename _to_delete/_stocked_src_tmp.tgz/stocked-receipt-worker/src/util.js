// util.js — shared primitives: responses, CORS, auth compare, crypto codes,
// request IDs, and structured logging. No route logic lives here.

export const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, X-Stocked-Key, X-Stocked-Session, X-Stocked-Attest",
};

export function json(obj, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json", ...CORS_HEADERS, ...extraHeaders },
  });
}

export function withCors(response) {
  const headers = new Headers(response.headers);
  for (const [k, v] of Object.entries(CORS_HEADERS)) headers.set(k, v);
  return new Response(response.body, { status: response.status, headers });
}

/** Constant-time string comparison so a wrong X-Stocked-Key can't be timing-probed. */
export function timingSafeEqual(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return result === 0;
}

// ── Crypto-secure household codes (improvement #4) ────────────────────────────
// Uses Web Crypto (getRandomValues) rather than the predictable JS PRNG: invite
// codes must be unguessable so a third party can't enumerate a code to join a
// household. Rejection sampling keeps the alphabet perfectly uniform (no bias).
const HH_CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // 32 chars, no ambiguous 0/O/1/I
export function makeHouseholdCode(len = 8) {
  const n = HH_CODE_ALPHABET.length;            // 32 → a byte covers 8 codes exactly (256/32)
  const max = Math.floor(256 / n) * n;          // largest multiple of n ≤ 256 (256 here)
  let out = "";
  const buf = new Uint8Array(len * 2);
  while (out.length < len) {
    crypto.getRandomValues(buf);
    for (let i = 0; i < buf.length && out.length < len; i++) {
      if (buf[i] < max) out += HH_CODE_ALPHABET[buf[i] % n];
    }
  }
  return out;
}

/** A random hex token for hashed invitation tokens / session ids. */
export function randomToken(bytes = 16) {
  const buf = new Uint8Array(bytes);
  crypto.getRandomValues(buf);
  return [...buf].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** SHA-256 hex of a string (for storing hashed invite tokens, never the raw value). */
export async function sha256Hex(input) {
  const data = new TextEncoder().encode(String(input));
  const digest = await crypto.subtle.digest("SHA-256", data);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** Short correlation id assigned per request; echoed in logs and error bodies. */
export function makeRequestId() {
  return randomToken(8);
}

// ── Structured, privacy-safe logging (improvement #10) ────────────────────────
// One JSON line per request. Never logs request bodies, secrets, PII, or model
// text — only shape/metadata fields. Cloudflare Workers Logs ingests these.
export function logEvent(fields) {
  try {
    console.log(JSON.stringify({ ts: Date.now(), ...fields }));
  } catch {
    // logging must never throw into the request path
  }
}

/** Run best-effort background work without blocking the response (improvement #6). */
export function background(ctx, promise) {
  try {
    if (ctx && typeof ctx.waitUntil === "function") ctx.waitUntil(Promise.resolve(promise));
  } catch {
    // if the platform can't defer it, the work already started; swallow.
  }
}
